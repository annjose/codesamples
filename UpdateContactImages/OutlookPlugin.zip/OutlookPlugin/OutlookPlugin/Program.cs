﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Outlook = Microsoft.Office.Interop.Outlook;
using System.Diagnostics;

namespace OutlookPlugin
{
    class Program
    {
        private static Outlook.NameSpace session;
        private static List<Outlook.ContactItem> contactList = new List<Outlook.ContactItem>();
        private static bool foundDL = false;

        static void Main(string[] args)
        {
            //try
            //{
                Outlook.Application app = new Outlook.Application();
                session = app.ActiveExplorer().Session;
                if (session != null)
                {
                    // PopulateDistList("Bangalore All");
                    PopulateDistList("cg-india-desktop");
                }
            /*}
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured. Make sure that Outlook is running");
            }*/
        }

        private static void PopulateDistList(string dlName)
        {
            Outlook.AddressLists addressLists = session.AddressLists as Outlook.AddressLists;
            foreach (Outlook.AddressList addressList in addressLists)
            {
                Console.WriteLine("Address List Name: " + addressList.Name + "  # of entries: " + addressList.AddressEntries.Count);
                if (addressList.AddressListType == Outlook.OlAddressListType.olExchangeGlobalAddressList)
                {
                    foreach (Outlook.AddressEntry addressEntryFirstLevel in addressList.AddressEntries)
                    {
                        Console.WriteLine("Level Address Entry: " + addressEntryFirstLevel.Name);
                        if ( (addressEntryFirstLevel.AddressEntryUserType == Outlook.OlAddressEntryUserType.olExchangeDistributionListAddressEntry) && 
                              addressEntryFirstLevel.Name.StartsWith(dlName) )
                        {
                            foundDL = true;
                            Console.WriteLine("Getting DL members..");
                            GetDLMembers(addressEntryFirstLevel, dlName);
                            break;
                        }
                    }
                }
                if (foundDL)
                    break;
            }
            Console.WriteLine("Done! Check Ooutlook Contact list for changes");
        }

        private static void GetDLMembers(Outlook.AddressEntry addressEntry, string dlName)
        {
            if (addressEntry.AddressEntryUserType == Outlook.OlAddressEntryUserType.olExchangeDistributionListAddressEntry)
            {
                // Outlook.ContactItem contact = entry.GetContact();
                Console.WriteLine("DL Name: " + addressEntry.Name);
                Outlook.ExchangeDistributionList exchDL = addressEntry.GetExchangeDistributionList();

                Outlook.AddressEntries exchDLMembers = exchDL.GetExchangeDistributionListMembers();
                if (exchDLMembers != null)
                {
                    Console.WriteLine("\tMembers....");
                    foreach (Outlook.AddressEntry exchDLMember in exchDLMembers)
                    {
                        Console.WriteLine("\t" + exchDLMember.Name);
                        GetDLMembers(exchDLMember, exchDL.Name);
                    }
                }
            }
            else if (addressEntry.AddressEntryUserType == Outlook.OlAddressEntryUserType.olExchangeUserAddressEntry)
            {
                Debug.Write("\t\tUserName: " + addressEntry.Name + "\t UserAccount: " + addressEntry.Address);
                Outlook.ExchangeUser exchUser = addressEntry.GetExchangeUser();
                if (exchUser != null)
                {
                    Outlook.ContactItem localContact = ContactUtil.FindContact(exchUser, session);
                    if (localContact != null)
                    {
                        ContactUtil.CopyContact(exchUser, localContact);
                        localContact.Save();
                    }
                    else
                    {
                        Outlook.ContactItem newContact = ContactUtil.CreateNewContactFromExchangeUser(exchUser, session);
                        newContact.Save();
                    }
                }
            }
        }
    }
}
