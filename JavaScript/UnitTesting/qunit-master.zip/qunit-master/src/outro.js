
// Get a reference to the global object, like window in browsers
}( (function() {
	return this;
})() ));
