QUnit.start();

test("just a test", function( assert ) {
	expect(1);
	assert.ok(true);
});
